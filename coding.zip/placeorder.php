<?php
// Database configuration
$servername = "localhost"; // Change this to your database server hostname
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "project"; // Change this to your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Start session
session_start();

// Check if the user is authenticated
if (!isset($_SESSION['user_id'])) {
    // Redirect the user to the login page if not authenticated
    header("Location: login.php");
    exit(); // Terminate script execution
}

// Retrieve the user ID from the session
$userID = $_SESSION['user_id'];

// Check if the POST values are set before accessing them
if (isset($_POST['total_amount'], $_POST['username'], $_POST['address'], $_POST['phone'])) {
    // Retrieve the values
    $totalAmount = $_POST['total_amount'];
    $username = $_POST['username'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];

    // Proceed with insertion
} else {
    // Handle case where POST values are not set
    $missingValues = [];
    if (!isset($_POST['total_amount'])) {
        $missingValues[] = "Total Amount";
    }
    if (!isset($_POST['username'])) {
        $missingValues[] = "Username";
    }
    if (!isset($_POST['address'])) {
        $missingValues[] = "Address";
    }
    if (!isset($_POST['phone'])) {
        $missingValues[] = "Phone";
    }

    echo "Error: Missing POST values for " . implode(', ', $missingValues) . ".";
    exit(); // Terminate script execution
} 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extract data from the form submission
    $orderDate = date("Y-m-d H:i:s"); // Get the current date and time
    $status = "Pending"; // Set the status as "Pending" by default
    $name = isset($_POST['username']) ? $_POST['username'] : '';
    $address = isset($_POST['address']) ? $_POST['address'] : '';
    $phone = isset($_POST['phone']) ? $_POST['phone'] : '';
    $total = isset($_POST['total_amount']) ? $_POST['total_amount'] : '';



    // Handle the receipt file upload
    if (isset($_FILES["receipt"]) && $_FILES["receipt"]["error"] == 0) {
        // Move the uploaded file to a designated directory
        $uploadDir = "receipts/";
        $filename = basename($_FILES["receipt"]["name"]);
        if (move_uploaded_file($_FILES["receipt"]["tmp_name"], $uploadDir . $filename)) {

            // Insert the data into the database
            $insertQuery = "INSERT INTO orderss (user_id, order_date, status, total_amount, username, address, phone, uploaded_receipt) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";


            $stmt = mysqli_prepare($conn, $insertQuery);
            mysqli_stmt_bind_param($stmt, "isssdsss", $userID, $orderDate, $status, $total, $username, $address, $phone, $filename);
            $insertResult = mysqli_stmt_execute($stmt);


// Execute the prepared statement
$insertResult = mysqli_stmt_execute($stmt);

            // Check for errors
            if (!$insertResult) {
                die("Error inserting record: " . mysqli_error($conn));
            }

            $orderID = 33; // Assuming the order ID is 33
            $selectQuery = "SELECT total_amount FROM orderss WHERE order_id = '{$orderID}'";
            $result = mysqli_query($conn, $selectQuery);

// Check if the query was successful
if ($result) {
    // Check if any rows were returned
    if(mysqli_num_rows($result) > 0) {
        // Fetch the total amount from the result set
        $row = mysqli_fetch_assoc($result);
        $totalAmountAfterInsertion = $row['total_amount'];

        // Output the total amount after insertion
        echo "Total Amount after Insertion: " . $totalAmountAfterInsertion;
    } else {
        echo "No records found for the newly inserted order.";
    }
} else {
    echo "Error retrieving total amount from database: " . mysqli_error($conn);
}


            // Check if the insertion was successful
            if ($insertResult) {
                // Redirect or perform other actions after successful insertion
                header("Location: success.php"); // Redirect to a success page
                exit();
            } else {
                // Handle the case where the insertion fails
                $errorMessage = "Failed to insert record into the database.";
            }
        } else {
            $errorMessage = "Error uploading receipt file.";
        }
    } else {
        $errorMessage = "No receipt file uploaded or an error occurred during upload.";
    }
} else {
    $errorMessage = "Invalid request.";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Place Order - Shahfarz HomeDeco</title>
    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #fdf7f1;
            line-height: 1.6;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }
        
        .dropbtn {
            background-color: transparent;
            color: white;
            padding: 14px;
            font-size: 16px;
            border: none;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #8d7359;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown:hover .dropbtn {
            background-color: transparent;
        }
        
        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        label {
            font-weight: bold;
            color: #555;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
        }

        .input-group input[type="file"] {
            display: none;
        }

        .input-group .upload-btn {
            background-color: #957b61;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .input-group .upload-btn:hover {
            background-color: #7c6957;
        }

        .image-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .image-container img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }

        /* Popup styles */
        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #c5b19c;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            z-index: 9999;
            width: 300px; /* Adjust width as needed */
        }

        .popup-content {
            text-align: center;
        }

        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            color: #333;
            cursor: pointer;
            font-size: 20px;
            transition: color 0.3s;
        }

        .close-btn:hover {
            color: #000;
        }

    </style>
</head>

<body>
    <div class="header">
        <a href="homepage.html" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepage.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompage.php">Dining Room</a>
                    <a href="livingroompage.php">Living Room</a>
                    <a href="bedroompage.php">Bedroom</a>
                    <a href="entryroompage.php">Entry Room</a>
                </div>
            </div>
    <a href="contactus.php">Contact Us</a>
    <a href="testimonial.php">Testimonial</a>
    <a class="cart" href="cart.php">
        <i class="fa fa-shopping-cart cart-icon"></i>
    </a>
    <a class="profile" href="profile.php">
                <i class="fa fa-user profile-icon"></i>
            </a>
        </div>
    </div>
    

    <div class="container">
        <h2>Payment Details</h2>
        <div class="bank-details">
            <h3>Bank Account Details</h3>
            <div class="image-container">
                <img src="bank.png" alt="Bank Account Details">
            </div>
        </div>

           <!-- Display total amount -->
        <div>
            <p>Total Amount: <span id="total"><?php echo isset($_POST['total_amount']) ? $_POST['total_amount'] : ''; ?></span></p>
        </div>

        <br>
        <h2>Upload Receipt</h2>

        <h2>Image Files Only - JPEG, PNG</h2>
        <div class="receipt-upload">
            <form action="upload_receipt.php" method="post" enctype="multipart/form-data">
                <label for="receipt">Upload Receipt:</label>
                <input type="file" id="receipt" name="receipt" accept="image/*" class="file-input">
                <!-- Additional hidden fields for user ID and total amount -->
                <input type="hidden" name="user_id" value="<?php echo isset($_POST['user_id']) ? $_POST['user_id'] : ''; ?>"> <!-- Example: Replace 1 with the actual user ID -->
                <input type="hidden" name="name" value="<?php echo isset($_POST['username']) ? $_POST['username'] : ''; ?>">
    <input type="hidden" name="address" value="<?php echo isset($_POST['address']) ? $_POST['address'] : ''; ?>">
    <input type="hidden" name="phone" value="<?php echo isset($_POST['phone']) ? $_POST['phone'] : ''; ?>">
    <!-- Hidden input field for total amount -->
    <input type="hidden" name="total_amount" value="<?php echo isset($_POST['total_amount']) ? $_POST['total_amount'] : ''; ?>">

                
                <button type="submit" class="upload-btn" onclick="showPopup()">UPLOAD</button>
            </form>
        </div>
    </div>
    
    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutus.php">About</a>
            <a href="privacypolicy.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faq.php">FAQ</a>
            <a href="contactus.php">Contact Us</a>
            <a href="refundpolicy.php">Refund Policy</a>
        </div>
    </footer>

    <!-- Popup -->
    <div class="popup" id="popup">
        <div class="popup-content">
            <span class="close-btn" onclick="closePopup()">&times;</span>
            <h2>Thank you for your purchase!</h2>
            <p>Our team will contact you if there are any issues.</p>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
            let totalAmount = 0;

            // Calculate total amount
            cartItems.forEach(item => {
                totalAmount += item.price * item.quantity;
            });

            // Set total amount value in the span element
            document.getElementById('total').textContent = 'RM' + totalAmount.toFixed(2);

            const cartNotification = document.getElementById('cart-notification');

            function updateCartNotification() {
                const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
                cartNotification.textContent = totalItems;
            }

            updateCartNotification(); // Ensure the function is called on each page load
        });
    </script>

</body>

</html>
