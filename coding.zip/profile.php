<?php
// Retrieve the user ID from the session
session_start();

if (!isset($_SESSION['user_id'])) {
    // Redirect to the login page if the user is not authenticated
    header("Location: login.php");
    exit();
}

// Database Connection
$conn = mysqli_connect("localhost", "root", "", "project");

// Retrieve user data using the user ID
$userID = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = $userID";
$result = mysqli_query($conn, $query);

// Initialize $userData as an empty array
$userData = [];

if ($result && mysqli_num_rows($result) > 0) {
    $userData = mysqli_fetch_assoc($result);
}

// Function to calculate total products in cart for the current user
function calculateTotalProductsInCart() {
    if(isset($_SESSION['user_id'])) {
        $userid = $_SESSION['user_id']; // Retrieve user ID from session

        // Database Connection
        $conn = mysqli_connect("localhost", "root", "", "project");

        // Prepare SQL query
        $sql = "SELECT SUM(quantity) AS total_products FROM cart WHERE user_id = ?";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameter
        $stmt->bind_param('i', $userid);

        // Execute statement
        $stmt->execute();

        // Get result
        $result = $stmt->get_result()->fetch_assoc();

        // Close statement and database connection
        $stmt->close();
        $conn->close();

        return $result['total_products']; // Return total products
    } else {
        return 0; // If user ID is not set, return 0
    }
}


// Example usage:
$totalProducts = calculateTotalProductsInCart();

// Close the database connection
mysqli_close($conn);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Your Profile - Shahfarz HomeDeco</title>
    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: #fdf7f1;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            color: #564c41;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        .dropbtn {
            background-color: transparent;
            color: white;
            padding: 14px;
            font-size: 16px;
            border: none;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #8d7359;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown:hover .dropbtn {
            background-color: transparent;
        }

        /* Profile Page Styles */
        .profile-container {
            max-width: 900px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .profile-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-details {
            margin-bottom: 20px;
        }

        .profile-section {
            margin-bottom: 20px;
        }

        .profile-section h2 {
            border-bottom: 2px solid #564c41;
            padding-bottom: 10px;
            margin-bottom: 20px;
            color: #564c41;
        }

        .profile-details p {
            margin-bottom: 10px;
        }

        /* "Edit Profile" button styles */
        .edit-profile-button-container {
            text-align: center;
        }

        .edit-profile-button {
            display: inline-block;
            padding: 12px 20px;
            background-color: #564c41;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
            transition: background-color 0.3s;
        }

        .edit-profile-button:hover {
            background-color: #8d7359;
        }

        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-top: auto;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }
    </style>
</head>

<body>
    <div class="header">
        <a href="homepage.html" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepage.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompage.php">Dining Room</a>
                    <a href="livingroompage.php">Living Room</a>
                    <a href="bedroompage.php">Bedroom</a>
                    <a href="entryroompage.php">Entry Room</a>
                </div>
            </div>
            <a href="contactus.php">Contact Us</a>
            <a href="testimonial.php">Testimonial</a>
            <a class="cart" href="cart.php">
    <i class="fa fa-shopping-cart cart-icon"></i>
    <span id="cart-notification"><?php echo $totalProducts; ?></span>
</a>

            <a class="profile" href="profile.php">
                <i class="fa fa-user profile-icon"></i>
            </a>
        </div>
    </div>

    <!-- Profile Container -->
    <div class="profile-container">
        <div class="profile-header">
            <h1>Your Profile</h1>
        </div>
        <div class="profile-details">
            <!-- Personal Information Section -->
            <div class="profile-section">
                <h2>Personal Information</h2>
                <!-- Check if $userData is not empty before accessing its values -->
                <?php if (!empty($userData)): ?>
                    <p><strong>Name:</strong> <?php echo $userData['username']; ?></p>
                    <p><strong>Email:</strong> <?php echo $userData['email']; ?></p>
                    <!-- Additional Fields -->
                    <p><strong>Phone Number:</strong> <?php echo $userData['phone']; ?></p>
                    <p><strong>Address:</strong> <?php echo $userData['address']; ?></p>
                    <!-- End of Additional Fields -->
                <?php else: ?>
                    <p>No user data found.</p>
                <?php endif; ?>
            </div>

            <!-- "Edit Profile" and "Logout" buttons -->
            <div class="edit-profile-button-container">
                <a href="editprofile.php" class="edit-profile-button">Edit Profile</a>
                <a href="logout.php" class="edit-profile-button">Logout</a>
            </div>
        </div>
        <!-- Add more profile sections as needed -->
    </div>

    <!-- Footer -->
    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutus.php">About</a>
            <a href="privacypolicy.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faq.php">FAQ</a>
            <a href="contactus.php">Contact Us</a>
            <a href="refundpolicy.php">Refund Policy</a>
        </div>
    </footer>


</body>

</html>
