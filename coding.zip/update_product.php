<?php
// Include the database configuration file
include 'db_config.php';

// Check if it's a valid PUT request and if the 'id' parameter is set
if ($_SERVER["REQUEST_METHOD"] == "PUT" && isset($_GET['id'])) {
    // Sanitize the input to prevent SQL injection
    $productId = intval($_GET['id']);

    // Retrieve the current product details from the database
    $sql = "SELECT * FROM products WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the product exists
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
</head>

<body>
    <h1>Edit Product</h1>
    <form action="process_update_product.php?id=<?php echo $productId; ?>" method="post">
    <label for="product_name">Product Name:</label><br>
    <input type="text" id="product_name" name="product_name" value="<?php echo $row['product_name']; ?>"><br>

    <label for="product_price">Product Price (RM):</label><br>
    <input type="number" id="product_price" name="product_price" step="0.01" value="<?php echo $row['product_price']; ?>"><br>

    <label for="product_image_path">Product Image Path:</label><br>
    <input type="text" id="product_image_path" name="product_image_path" value="<?php echo $row['product_image_path']; ?>"><br>

    <label for="category">Product Category:</label><br>
    <input type="text" id="category" name="category" value="<?php echo $row['category']; ?>"><br>

    <input type="submit" value="Update Product">
</form>
</body>

</html>
<?php
    } else {
        // Product not found
        echo "Product not found.";
    }

    // Close the prepared statement and database connection
    $stmt->close();
    $conn->close();
} else {
    // Invalid request
    echo "Invalid request.";
}
?>
