<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Privacy Policy - SHAHFARZ HOMEDECO</title>
    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #fdf7f1;
            line-height: 1.6;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        /* Main Content Styles */
        header {
            background-color: #ddbf86;
            color: #fff;
            text-align: center;
            padding: 20px 0;
        }

        main {
            padding: 20px;
        }

        h1, h2 {
            color: #333;
        }

        h2 {
            margin-top: 20px;
        }

        p {
            margin-bottom: 20px;
        }

        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }
		
		.dropbtn {
  background-color: transparent;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #8d7359;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: transparent;}
		
    </style>
</head>

<body>
<div class="header">
        <a href="homepageadmin.php" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepageadmin.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompageadmin.php">Dining Room</a>
                    <a href="livingroompageadmin.php">Living Room</a>
                    <a href="bedroompageadmin.php">Bedroom</a>
                    <a href="entryroompageadmin.php">Entry Room</a>
                </div>
            </div>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="testimonialadmin.php">Testimonial</a>
            <a class="add-product" href="addproductform.php">
                <i class="fa fa-plus"></i>
            </a>
            <a class="order" href="order_admin.php">
    <i class="fa fa-shopping-cart"></i>
</a>
        </div>
    </div>

    <header>
        <h1>Privacy Policy</h1>
    </header>

    <main>

        <h2>Your Privacy Matters to Us</h2>

        <p>At SHAHFARZ HOMEDECO, we are committed to maintaining the trust and confidence of our visitors to our web
            site. In particular, we want you to know that SHAHFARZ HOMEDECO is not in the business of selling, renting
            or trading email lists with other companies and businesses for marketing purposes. We just don’t do
            that. But just in case you don’t believe us, in this Privacy Policy, we’ve provided lots of detailed
            information on when and why we collect your personal information, how we use it, the limited conditions
            under which we may disclose it to others and how we keep it secure. Read on.</p>

        <h2>Cookies</h2>

        <p>Our website uses cookies to collect information. This includes information about browsing and purchasing
            behavior by people who access our websites. This includes information about pages viewed, products
            purchased and the customer journey around our websites. Detailed information is set out in our Cookie
            Policy.</p>

        <h2>What We Do With Your Information</h2>

        <p>When you purchase something from our store, as part of the buying and selling process, we collect the
            personal information you give us such as your name, address and email address. When you browse our store,
            we also automatically receive your computer’s internet protocol (IP) address in order to provide us with
            information that helps us learn about your browser and operating system. Email marketing (if applicable):
            With your permission, we may send you emails about our store, new products and other updates.</p>

        <h2>Consent</h2>

        <p>How do you get my consent?</p>

        <p>When you provide us with personal information to complete a transaction, verify your credit card, place an
            order, arrange for a delivery or return a purchase, we imply that you consent to our collecting it and
            using it for that specific reason only.</p>

        <p>If we ask for your personal information for a secondary reason, like marketing, we will either ask you
            directly for your expressed consent or provide you with an opportunity to say no.</p>

        <p>How do I withdraw my consent?</p>

        <p>If after you opt-in, you change your mind, you may withdraw your consent for us to contact you, for the
            continued collection, use or disclosure of your information, at any time, by contacting us at email at : farzlinda@gmail.com or wbudeen@gmail.com&nbsp;
        </p>

        <h2>Changes to this Privacy Policy</h2>

        <p>We reserve the right to modify this privacy policy at any time, so please review it frequently. Changes and
            clarifications will take effect immediately upon their posting on the website. If we make material changes
            to this policy, we will notify you here that it has been updated, so that you are aware of what information
            we collect, how we use it, and under what circumstances, if any, we use and/or disclose it.</p>

        <h2>Questions and Contact Information</h2>

        <p>If you would like to: access, correct, amend or delete any personal information we have about you, register
            a complaint, or simply want more information, contact us at +6013-6553197 or farzlinda@gmail.com
        </p>
    </main>

    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutusadmin.php">About</a>
            <a href="privacypolicyadmin.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faqadmin.php">FAQ</a>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="refundpolicyadmin.php">Refund Policy</a>
        </div>
    </footer>

</body>

</html>
