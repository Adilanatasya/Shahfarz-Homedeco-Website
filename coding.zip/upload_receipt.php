<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Receipt Upload</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            text-align: center;
            padding: 50px;
        }

        .button {
            background-color: #a3826c;
            border: none;
            color: black;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 20px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #bd9e8a;
        }
    </style>
</head>
<body>
    <?php
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "project";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Handle receipt upload
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if a receipt file is uploaded
        if (isset($_FILES["receipt"])) {
            $target_dir = "uploads/"; // Modify this directory as needed
            $target_file = $target_dir . basename($_FILES["receipt"]["name"]);

            // Move uploaded file to the server
            if (move_uploaded_file($_FILES["receipt"]["tmp_name"], $target_file)) {
                // Retrieve data from previous page
                $user_id = $_POST['user_id'];
                $order_date = date("Y-m-d H:i:s");
                $status = 'Pending';
                $total = $_POST['total_amount'];
                $username = $_POST['name'];
                $address = $_POST['address'];
                $phone = $_POST['phone'];

                // Prepare and bind the insertion statement
                $insertQuery = "INSERT INTO orderss (user_id, order_date, status, total_amount, username, address, phone, uploaded_receipt) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($insertQuery);
                $stmt->bind_param("isssssss", $user_id, $order_date, $status, $total, $username, $address, $phone, $target_file);

                // Execute the statement
if ($stmt->execute()) {
    echo "Receipt uploaded successfully!<br>";
    echo "Admin will send you messages<br>";
    echo "If urgent, contact us immediately!<br>";
} else {
    echo "Error: " . $stmt->error;
}


                // Close statement
                $stmt->close();
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    }

    $conn->close();
    ?>
    <br>
    <a href="homepage.php" class="button">Go to Homepage</a>
</body>
</html>
