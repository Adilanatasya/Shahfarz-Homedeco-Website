<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

// Check if the user is authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user data from the database
$userID = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = $userID";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $userData = mysqli_fetch_assoc($result);
} else {
    // Handle the case where user data is not found
    $userData = array();
}

// Handle the form submission for updating profile information
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Extract the form data
    $newUsername = $_POST['username'];
    $newEmail = $_POST['email'];
    $newPhone = $_POST['phone'];
    $newAddress = $_POST['address'];
    $newPassword = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    // Check if the new password and confirm password match
    if ($newPassword !== $confirmPassword) {
        $errorMessage = "New password and confirm password do not match.";
    } else {
        // Update the user information in the database, including the password
        $updateQuery = "UPDATE users SET username = '$newUsername', email = '$newEmail', phone = '$newPhone', address = '$newAddress', password = '$newPassword' WHERE id = $userID";

        // Execute the update query
        $updateResult = mysqli_query($conn, $updateQuery);

        // Check for errors
        if (!$updateResult) {
            die("Error updating record: " . mysqli_error($conn));
        }

        // Check if the update was successful
        if ($updateResult) {
            // Redirect to the profile page after a successful update
            header("Location: profile.php");
            exit();
        } else {
            // Handle the case where the update fails
            $errorMessage = "Failed to update profile. Please try again.";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Edit Your Profile - Shahfarz HomeDeco</title>
    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: #fdf7f1;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        .dropbtn {
            background-color: transparent;
            color: white;
            padding: 14px;
            font-size: 16px;
            border: none;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #8d7359;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown:hover .dropbtn {
            background-color: transparent;
        }

        /* Edit Profile Form Styles */
        .edit-profile-container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .edit-profile-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .edit-profile-form {
            display: flex;
            flex-direction: column;
        }

        .edit-profile-form label {
            margin-bottom: 8px;
        }

        .edit-profile-form input,
        .edit-profile-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .edit-profile-form input[type="submit"] {
            background-color: #564c41;
            color: #fff;
            cursor: pointer;
        }

        .edit-profile-form input[type="submit"]:hover {
            background-color: #8d7359;
        }


        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-top: auto;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }
    </style>
</head>

<body>
    <div class="header">
        <a href="homepage.html" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepage.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompage.php">Dining Room</a>
                    <a href="livingroompage.php">Living Room</a>
                    <a href="bedroompage.php">Bedroom</a>
                    <a href="entryroompage.php">Entry Room</a>
                </div>
            </div>
            <a href="contactus.php">Contact Us</a>
            <a href="testimonial.php">Testimonial</a>
            <a class="cart" href="cart.php">
                <i class="fa fa-shopping-cart cart-icon"></i>
                <span id="cart-notification">0</span>
            </a>
            <a class="profile" href="profile.php">
                <i class="fa fa-user profile-icon"></i>
            </a>
        </div>
    </div>

     <!-- Edit Profile Form -->
     <div class="edit-profile-container">
        <div class="edit-profile-header">
            <h1>Edit Your Profile</h1>
        </div>
        <div class="edit-profile-form">
            <form action="editprofile.php" method="POST">
                <!-- Display existing information in input fields -->
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($userData['username']); ?>" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($userData['email']); ?>" required>

                <!-- Additional Fields -->
                <label for="phone">Phone Number:</label>
                <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($userData['phone']); ?>">

                <label for="address">Address:</label>
                <textarea id="address" name="address"><?php echo htmlspecialchars($userData['address']); ?></textarea>

                <!-- New Password Fields -->
                <label for="password">New Password:</label>
                <input type="password" id="password" name="password" placeholder="Enter new password">

                <label for="confirm_password">Confirm New Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm new password">

                <input type="submit" value="Update Profile">
            </form>
        </div>
    </div>

    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutus.php">About</a>
            <a href="privacypolicy.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faq.php">FAQ</a>
            <a href="contactus.php">Contact Us</a>
            <a href="refundpolicy.php">Refund Policy</a>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
            const cartNotification = document.getElementById('cart-notification');

            function updateCartNotification() {
                const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
                cartNotification.textContent = totalItems;
            }

            updateCartNotification(); // Ensure the function is called on each page load
        });
    </script>

</body>

</html>
