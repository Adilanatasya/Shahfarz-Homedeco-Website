<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>SHAHFARZ HOMEDECO</title>
    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #fdf7f1;
            line-height: 1.6;
            margin: 0;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        .dropbtn {
            background-color: transparent;
            color: white;
            padding: 14px;
            font-size: 16px;
            border: none;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #8d7359;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown:hover .dropbtn {
            background-color: transparent;
        }

        /* Zigzag Layout Styles */
        .container {
            padding: 2% 5%;
        }

        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        .column-66,
        .column-33 {
            float: left;
            width: 100%;
            box-sizing: border-box;
            padding: 20px;
        }

        .large-font {
            font-size: 48px;
        }

        .xlarge-font {
            font-size: 64px;
        }

        .button {
            border: none;
            color: white;
            padding: 14px 28px;
            font-size: 16px;
            cursor: pointer;
            background-color: #16537e;
        }

        img {
            display: block;
            max-width: 100%;
            height: auto;
            margin: 0 auto; /* Center align images */
        }

        @media screen and (min-width: 600px) {
            .column-66 {
                width: 66.66666%;
                float: left;
            }

            .column-33 {
                width: 33.33333%;
                float: left;
            }
        }

        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }
    </style>
</head>

<body>
<div class="header">
        <a href="homepageadmin.php" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepageadmin.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompageadmin.php">Dining Room</a>
                    <a href="livingroompageadmin.php">Living Room</a>
                    <a href="bedroompageadmin.php">Bedroom</a>
                    <a href="entryroompageadmin.php">Entry Room</a>
                </div>
            </div>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="testimonialadmin.php">Testimonial</a>
            <a class="add-product" href="addproductform.php">
                <i class="fa fa-plus"></i>
            </a>
            
            <a class="order" href="order_admin.php">
    <i class="fa fa-shopping-cart"></i>
</a>
        </div>
    </div>

    <!-- Living Room Section -->
    <div class="container">
        <div class="row">
            <div class="column-66">
              <p style="text-align: center; font-size: 24px;">Living Room</p>
              <p style="text-align: center; font-size: 24px;">&nbsp;</p>
<p style="text-align: center;">A living room is a room in a home used for socializing, entertaining, reading, watching TV, or playing games. It's often the first room that visitors see when entering the house.</p>
                <p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><a href="livingroompageadmin.php" class="button">VIEW NOW</a></p>
            </div>
            <div class="column-33">
                <img src="living.jpg" alt="Living Room">
            </div>
        </div>
    </div>

    <!-- Dining Room Section -->
    <div class="container" style="background-color:#faf0e7">
        <div class="row">
            <div class="column-33">
                <img src="kiki.jpg" alt="Dining Room" width="500" height="450">
            </div>
            <div class="column-66">
              <p style="text-align: center; font-size: 24px;">Dining Room</p>
              <p style="text-align: center; font-size: 24px;">&nbsp;</p>
<p style="text-align: center;">A dining room is a room where people eat meals. Dining rooms are usually located near the kitchen to make serving food easier.</p>
                <p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><a href="diningroompageadmin.php" class="button" style="background-color:#16537e;">VIEW NOW</a></p>
          </div>
        </div>
    </div>

    <!-- Entry Room Section -->
    <div class="container">
        <div class="row">
            <div class="column-66">
              <p style="text-align: center; font-size: 24px;">Entry Room</p>
              <p style="text-align: center; font-size: 24px;">&nbsp;</p>
<p style="text-align: center;">An entry way is a transitional space found in smaller homes, apartments, and homes with an open-floor plan.</p>
                <p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><a href="entryroompageadmin.php" class="button">VIEW NOW</a></p>
            </div>
            <div class="column-33">
                <img src="entry.jpg" alt="Entry Room" width="564" height="450">
            </div>
        </div>
    </div>

    <!-- Bedroom Section -->
    <div class="container" style="background-color:#faf0e7">
        <div class="row">
            <div class="column-33">
                <img src="bedroom.jpg" alt="Bedroom" width="564" height="376">
            </div>
            <div class="column-66">
              <p style="text-align: center; font-size: 24px;">Bedroom</p>
              <p style="text-align: center; font-size: 24px;">&nbsp;</p>
<p style="text-align: center;">A bedroom is a room in a home or apartment used for sleeping. It typically contains a bed, bedding, a window for egress, a door for privacy, and a minimum size requirement.</p>
                <p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><a href="bedroompageadmin.php" class="button" style="background-color:#16537e;">VIEW NOW</a></p>
            </div>
        </div>
    </div>

    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutusadmin.php">About</a>
            <a href="privacypolicyadmin.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faqadmin.php">FAQ</a>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="refundpolicyadmin.php">Refund Policy</a>
        </div>
    </footer>
</body>

</html>
