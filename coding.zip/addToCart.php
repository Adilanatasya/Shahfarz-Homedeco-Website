<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "Error: User not logged in";
    exit;
}

// Check if product ID is provided
if (!isset($_POST['productId'])) {
    echo "Error: Product ID not provided";
    exit;
}

// Database connection details
$hostname = "localhost";
$username = "root";
$password = "";
$database = "project";

// Create a connection to the database
$conn = new mysqli($hostname, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    echo "Error: Connection failed: " . $conn->connect_error;
    exit;
}

// Retrieve product details based on productId
$productId = $_POST['productId'];
$sql = "SELECT * FROM products WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $productId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Product found, fetch its details
    $row = $result->fetch_assoc();
    $productName = $row['product_name'];
    $productPrice = $row['product_price'];

    // Insert the product into the user's cart
    $userId = $_SESSION['user_id'];
    $username = $_SESSION['username']; // Assuming you have username in the session
    $quantity = 1; // Assuming adding one quantity by default
    $sql = "INSERT INTO cart (user_id, username, product_id, product_name, product_price, quantity) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isissi", $userId, $username, $productId, $productName, $productPrice, $quantity);
    if ($stmt->execute()) {
        echo "Product added to cart successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Error: Product not found";
}

// Close the database connection
$conn->close();
?>
