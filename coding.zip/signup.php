<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Sign Up - Shahfarz HomeDeco</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url("wallpsign.jpg") center/cover no-repeat;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            align-items: center;
            justify-content: center;
            margin: 0;
            background-color: #f3f3f3;
        }

        .registration-container {
            width: 80%;
            max-width: 600px;
            padding: 30px;
            border: 2px solid #957b61;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        h1 {
            text-align: center;
            color: #957b61;
            margin-bottom: 20px;
        }

        .input-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 15px;
        }

        .input-group label {
            color: #333;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .input-group input,
        .input-group textarea {
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .input-group textarea {
            resize: vertical;
        }

        .side-by-side {
            display: flex;
            gap: 10px;
        }

        .side-by-side .input-group {
            flex: 1;
        }

        button {
            background-color: #957b61;
            border: none;
            color: white;
            padding: 12px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #7c6957;
        }

        p {
            text-align: center;
            margin-top: 20px;
            color: #555;
        }

        a {
            color: #957b61;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        .success-message {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-top: 20px;
            text-align: center;
        }

    </style>
</head>

<body>
    <!-- Registration Form -->
    <div class="registration-container">
    <h1><span class="highlight-text">SHAHFARZ HOMEDECO</span></h1>
        <div class="registration-header">
            <h1>Sign Up</h1>
        </div>

        <div class="registration-form">
            <!-- Check if registration successful and display the message -->
            <?php
            if (isset($_GET['success']) && $_GET['success'] == 'true') {
                echo '<div class="success-message">Registration successful!</div>';
            }
            ?>
            <!-- End of success message -->


        <div class="registration-form">
            <form action="signup_process.php" method="POST">
                <div class="side-by-side">
                    <div class="input-group">
                        <label for="username">Username:</label>
                        <input type="text" id="username" name="username" required>
                    </div>

                    <div class="input-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                </div>

                <div class="side-by-side">
                    <div class="input-group">
                        <label for="password">Password:</label>
                        <input type="password" id="password" name="password" required>
                    </div>

                    <div class="input-group">
                        <label for="phone">Phone Number:</label>
                        <input type="text" id="phone" name="phone">
                    </div>
                </div>

                <div class="input-group">
                    <label for="address">Address:</label>
                    <textarea id="address" name="address" rows="4"></textarea>
                </div>

                <button type="submit">Sign Up</button>
            </form>
            <p>Already have an account? <a href="login.php">Log in here</a></p>
        </div>
    </div>
</body>

</html>
