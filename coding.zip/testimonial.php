<?php
session_start(); // Start the session

// Function to establish a PDO database connection
function db_connect() {
    $host = 'localhost'; // Change this to your database host
    $dbname = 'project'; // Change this to your database name
    $username = 'root'; // Change this to your database username
    $password = ''; // Change this to your database password

    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}

// Function to calculate total products in cart for the current user
function calculateTotalProductsInCart() {
    if(isset($_SESSION['user_id'])) {
        $userid = $_SESSION['user_id']; // Retrieve user ID from session

        $conn = db_connect(); // Connect to the database

        // Prepare SQL query
        $sql = "SELECT SUM(quantity) AS total_products FROM cart WHERE user_id = :userid";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':userid', $userid, PDO::PARAM_INT);

        // Execute statement
        $stmt->execute();

        // Fetch total products
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Close statement and database connection
        $stmt = null;
        $conn = null;

        return $result['total_products']; // Return total products
    } else {
        return 0; // If user ID is not set, return 0
    }
}

// Example usage:
$totalProducts = calculateTotalProductsInCart();

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Testimonials - SHAHFARZ HOMEDECO</title>
    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #fdf7f1;
            line-height: 1.6;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }

        /* Testimonial Styles */
        .testimonial-container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .testimonial {
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #ddd;
            display: flex;
        }

        .testimonial:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }

        .testimonial-image {
            flex: 0 0 80px;
            margin-right: 20px;
        }

        .testimonial-image img {
            width: 100%;
        }

        .testimonial-content {
            flex: 1;
        }

        .testimonial-author {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .testimonial-date {
            color: #777;
        }
		
		.dropbtn {
  background-color: transparent;
  color: white;
  padding: 14px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #8d7359;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: transparent;}
		
    </style>
</head>

<body>
    <div class="header">
        <a href="homepage.html" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepage.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompage.php">Dining Room</a>
                    <a href="livingroompage.php">Living Room</a>
                    <a href="bedroompage.php">Bedroom</a>
                    <a href="entryroompage.php">Entry Room</a>
                </div>
            </div>
    <a href="contactus.php">Contact Us</a>
    <a href="testimonial.php">Testimonial</a>
    <a class="cart" href="cart.php">
    <i class="fa fa-shopping-cart cart-icon"></i>
    <span id="cart-notification"><?php echo $totalProducts; ?></span>
</a>

    <a class="profile" href="profile.php">
                <i class="fa fa-user profile-icon"></i>
            </a>
        </div>
    </div>

    <div class="testimonial-container">
        <div class="testimonial">
            <div class="testimonial-image">
                <img src="test1.jpg" alt="Testimonial 1">
            </div>
            <div class="testimonial-content">
                <p>"The deliver is friendly and helpful and the good delivered quite fast!" </p>
                <p class="testimonial-author">Rahman</p>
                <p class="testimonial-date">July 29, 2022&nbsp; &nbsp;</p>
          </div>
        </div>
		
		<div class="testimonial">
            <div class="testimonial-image">
              <img src="test2.jpg" alt="Testimonial 1">
            </div>
            <div class="testimonial-content">
                <p>"The service is good and friendly. Definitely will buy it again!"</p>
                <p class="testimonial-author">Aizat</p>
                <p class="testimonial-date">December 12, 2022</p>
          </div>
        </div>
		
        <div class="testimonial">
            <div class="testimonial-image">
              <img src="test3.jpg" alt="Testimonial 2">
            </div>
            <div class="testimonial-content">
                <p>"The material is good. Thank you for the fast delivery."&nbsp;&nbsp;</p>
                <p class="testimonial-author">Ariza</p>
                <p class="testimonial-date">April 25, 2023</p>
          </div>
        </div>
		
        <div class="testimonial">
            <div class="testimonial-image">
              <img src="test4.jpg" alt="Testimonial 3">
            </div>
            <div class="testimonial-content">
                <p>"Service is awesome. The owner is friendly and assist me until the products is secured."&nbsp; &nbsp; &nbsp; &nbsp;</p>
                <p class="testimonial-author">Khairul&nbsp;</p>
                <p class="testimonial-date">November 9, 2023</p>
          </div>
        </div>
		
		<div class="testimonial">
            <div class="testimonial-image">
              <img src="test5.jpg" alt="Testimonial 2">
            </div>
          <div class="testimonial-content">
            <p>"Assembling team is professional"&nbsp;&nbsp;</p>
                <p class="testimonial-author">Bad&nbsp;</p>
              <p class="testimonial-date">November 28, 2023</p>
          </div>
        </div>
		
		<div class="testimonial">
            <div class="testimonial-image">
              <img src="test6.jpg" alt="Testimonial 2">
            </div>
            <div class="testimonial-content">
                <p>"Product is easy to use for kids.They love it."&nbsp;&nbsp;</p>
                <p class="testimonial-author">Kamalia&nbsp;</p>
                <p class="testimonial-date">January 10, 2024</p>
          </div>
        </div>
		
		<div class="testimonial">
            <div class="testimonial-image">
              <img src="test7.jpg" alt="Testimonial 2">
            </div>
            <div class="testimonial-content">
                <p>"Fast delivery. Thank you!"&nbsp;&nbsp;</p>
                <p class="testimonial-author">Adam&nbsp;</p>
                <p class="testimonial-date">February 2, 2024</p>
          </div>
        </div>
		
    </div>

    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutus.php">About</a>
            <a href="privacypolicy.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faq.php">FAQ</a>
            <a href="contactus.php">Contact Us</a>
            <a href="refundpolicy.php">Refund Policy</a>
        </div>
    </footer>

    

</body>

</html>
