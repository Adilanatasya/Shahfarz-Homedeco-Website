<?php
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include your database connection code here

    // Retrieve user input from the form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Validate input (you should add more validation according to your requirements)

    // Example: Check if the username is not empty
    if (empty($username)) {
        die("Username is required");
    }

    // Example: Check if the password is not empty
    if (empty($password)) {
        die("Password is required");
    }

    // Check if the username indicates an admin
    if (is_admin_username($username)) {
        // Admin user
        $_SESSION['user_id'] = get_user_id($username); // Set the user ID in the session
        header("Location: homepageadmin.php");
        exit();
    }

    // Connect to the database (replace with your actual connection code)
    $conn = mysqli_connect("localhost", "root", "", "project");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Example: Use a prepared statement to check if the username and password match
    $query = "SELECT * FROM users WHERE username=? AND password=?";

    // Create a prepared statement
    $stmt = mysqli_prepare($conn, $query);

    // Bind parameters
    mysqli_stmt_bind_param($stmt, "ss", $username, $password);

    // Execute the statement
    mysqli_stmt_execute($stmt);

    // Get result
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        // Regular user
        $_SESSION['user_id'] = $row['id']; // Set the user ID in the session
$_SESSION['username'] = $username; // Set the username in the session
header("Location: homepage.php");
exit();
    } else {
        // Login failed
        echo "Invalid username or password";
    }

    // Close the statement and the database connection
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
} else {
    // Redirect to the login page if the form is not submitted
    header("Location: login.php");
    exit();
}

// Function to check if the username indicates an admin
function is_admin_username($username) {
    // Customize this function based on your admin username pattern
    return (strpos($username, 'admin_') === 0);
}

// Function to get the user ID based on the username (replace with your actual logic)
function get_user_id($username) {
    // Implement your logic to retrieve the user ID based on the username
    // For example, query the database
    // Return the user ID
    return 1; // Replace with your actual logic
}
?>
