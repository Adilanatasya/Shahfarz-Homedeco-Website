<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Success</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
        }
        h1 {
            color: green;
        }
        p {
            margin-top: 20px;
        }
        a {
            color: blue;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <h1>Order Successfully Placed!</h1>
    <p>Your order has been successfully placed. Your order ID is: <?php echo isset($_GET['order_id']) ? $_GET['order_id'] : 'N/A'; ?></p>
    <p>Thank you for shopping with us!</p>
    <a href="homepage.php">Back to Homepage</a>
</body>
</html>
