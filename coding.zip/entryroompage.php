<?php
session_start(); // Start the session

// Database connection details
$hostname = "localhost";
$username = "root";
$password = "";
$database = "project";

// Create a connection to the database
$conn = new mysqli($hostname, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to calculate total products in cart for the current user
function calculateTotalProductsInCart() {
    if(isset($_SESSION['user_id'])) {
        $userid = $_SESSION['user_id']; // Retrieve user ID from session

        // Create a connection to the database
        $conn = new mysqli($GLOBALS['hostname'], $GLOBALS['username'], $GLOBALS['password'], $GLOBALS['database']);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare SQL query
        $sql = "SELECT SUM(quantity) AS total_products FROM cart WHERE user_id = ?";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bind_param("i", $userid);

        // Execute statement
        $stmt->execute();

        // Get result
        $result = $stmt->get_result();

        // Fetch total products
        $row = $result->fetch_assoc();
        $totalProducts = $row['total_products'];

        // Close statement and database connection
        $stmt->close();
        $conn->close();

        return $totalProducts; // Return total products
    } else {
        return 0; // If user ID is not set, return 0
    }
}

// Fetch products from the database for the "Entry Room" category
$category = "entry room";
$sql = "SELECT id, product_name, product_price, product_image_path FROM products WHERE category = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $category);
$stmt->execute();
$result = $stmt->get_result();

// Example usage:
$totalProducts = calculateTotalProductsInCart();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>ENTRY ROOM</title>
    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f2eee5;
            line-height: 1.6;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        /* Dropdown Styles */
        .dropbtn {
            background-color: transparent;
            color: white;
            padding: 13px;
            font-size: 16px;
            border: none;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {background-color: #8d7359;}

        .dropdown:hover .dropdown-content {display: block;}

        .dropdown:hover .dropbtn {background-color: transparent;}

        /* Product Section */
        .product-section {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 20px;
        }

        .product {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
        }

        .product-item {
            flex-basis: calc(33.33% - 20px);
            margin-bottom: 20px;
        }

        .product-image {
            position: relative;
            overflow: hidden;
            margin-bottom: 10px;
        }

        .product-image img {
            width: 100%;
            transition: transform 0.3s ease;
        }

        .product-image:hover img {
            transform: scale(1.1);
        }

        .product-details {
            margin-bottom: 10px;
        }

        .product-name {
            font-size: 18px;
            margin-bottom: 5px;
        }

        .product-price {
            font-size: 16px;
            color: #888;
            margin-bottom: 10px;
        }

        .add-to-cart {
            padding: 8px 16px;
            background-color: #000;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .add-to-cart:hover {
            background-color: #333;
        }

        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }
    </style>
</head>

<body>
    <div class="header">
        <a href="homepage.php" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepage.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompage.php">Dining Room</a>
                    <a href="livingroompage.php">Living Room</a>
                    <a href="bedroompage.php">Bedroom</a>
                    <a href="entryroompage.php">Entry Room</a>
                </div>
            </div>
    <a href="contactus.php">Contact Us</a>
    <a href="testimonial.php">Testimonial</a>
    <a class="cart" href="cart.php">
    <i class="fa fa-shopping-cart cart-icon"></i>
    <span id="cart-notification"><?php echo $totalProducts; ?></span>
</a>

    <a class="profile" href="profile.php">
                <i class="fa fa-user profile-icon"></i>
            </a>
        </div>
    </div>

    <div class="product-section">
        <div class="product">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="product-item">';
                    echo '<div class="product-image">';
                    echo '<img src="' . $row['product_image_path'] . '" alt="Product Image">';
                    echo '</div>';
                    echo '<div class="product-details">';
                    echo '<h2 class="product-name">' . $row['product_name'] . '</h2>';
                    echo '<p class="product-price">RM' . $row['product_price'] . '</p>';
                    echo '<button class="add-to-cart" data-productid="' . $row['id'] . '" data-price="' . $row['product_price'] . '">Add to Cart</button>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo 'No products found.';
            }
            ?>
        </div>
    </div>

    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutus.php">About</a>
            <a href="privacypolicy.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faq.php">FAQ</a>
            <a href="contactus.php">Contact Us</a>
            <a href="refundpolicy.php">Refund Policy</a>
        </div>
    </footer>
	
	<script>
       document.addEventListener("DOMContentLoaded", function() {
    // Get all elements with class "add-to-cart"
    var addToCartButtons = document.querySelectorAll('.add-to-cart');

    // Add event listener to each button
    addToCartButtons.forEach(function(button) {
        button.addEventListener('click', function(event) {
            // Get product ID from the button's data attribute
            var productId = button.getAttribute('data-productid');

            // Send AJAX request to addToCart.php
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "addToCart.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    alert(xhr.responseText);
                }
            };
            xhr.send("productId=" + productId);
        });
    });
});

    </script>
	

	
</body>

</html>


<?php
// Close the database connection
$conn->close();
?>