<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>FAQ - SHAHFARZ HOMEDECO</title>
    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #fdf7f1;
            line-height: 1.6;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        /* Main Content Styles */
        main {
            padding: 20px;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 15px;
        }

        h2 {
            margin-top: 20px;
            cursor: pointer;
            color: #555;
            font-size: 20px;
            padding: 10px;
            background-color: #e7d8bb;
            border-radius: 8px;
            transition: background-color 0.3s;
        }

        h2:hover {
            background-color: #ebe3d4;
        }

        p {
            margin-bottom: 20px;
        }

        /* FAQ Styles */
        .faq-item {
            margin-bottom: 20px;
        }

        .faq-answer {
            display: none;
            margin-bottom: 10px;
            background-color: #cfbfa2;
            padding: 10px;
            border-radius: 8px;
            transition: display 0.3s;
        }

        .faq-answer.show {
            display: block;
        }

        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-radius: 8px;
            margin-top: 20px;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }
		
		.dropbtn {
  background-color: transparent;
  color: white;
  padding: 14px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #8d7359;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: transparent;}
		
    </style>
</head>

<body>
<div class="header">
        <a href="homepageadmin.php" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepageadmin.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompageadmin.php">Dining Room</a>
                    <a href="livingroompageadmin.php">Living Room</a>
                    <a href="bedroompageadmin.php">Bedroom</a>
                    <a href="entryroompageadmin.php">Entry Room</a>
                </div>
            </div>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="testimonialadmin.php">Testimonial</a>
            <a class="add-product" href="addproductform.php">
                <i class="fa fa-plus"></i>
            </a>
            <a class="order" href="order_admin.php">
    <i class="fa fa-shopping-cart"></i>
</a>
        </div>
    </div>

    <main>
        <h1>Frequently Asked Questions (FAQ)</h1>

        <div class="faq-item">
            <h2 onclick="toggleAnswer('faq1')">How can I track my order?</h2>
            <p class="faq-answer" id="faq1">You can track your order by messaging the worker on WhatsApp.</p>
        </div>

        <div class="faq-item">
            <h2 onclick="toggleAnswer('faq2')">What is your return policy?</h2>
            <p class="faq-answer" id="faq2">We offer a 30-day return policy for most items. Please refer to our <a href="refundpolicy.html">Refund Policy</a> for more information.</p>
        </div>

        <div class="faq-item">
            <h2 onclick="toggleAnswer('faq3')">How do I contact customer support?</h2>
            <p class="faq-answer" id="faq3">You can contact our customer support team by emailing us at farzlinda@gmail.com or calling us at +60 13 655 3197.</p>
        </div>

        <div class="faq-item">
            <h2 onclick="toggleAnswer('faq4')">Do you offer installation?</h2>
            <p class="faq-answer" id="faq4">Yes, we offer installation services for a small additional fee.</p>
        </div>

        <div class="faq-item">
            <h2 onclick="toggleAnswer('faq5')">How long does shipping take?</h2>
            <p class="faq-answer" id="faq5">Shipping times vary depending on your location. Standard shipping typically takes 3-5 business days.</p>
        </div>

        <div class="faq-item">
            <h2 onclick="toggleAnswer('faq6')">Do you ship internationally?</h2>
            <p class="faq-answer" id="faq6">No, we do not offer international shipping.</p>
        </div>
    </main>

    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutusadmin.php">About</a>
            <a href="privacypolicyadmin.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faqadmin.php">FAQ</a>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="refundpolicyadmin.php">Refund Policy</a>
        </div>
    </footer>

    <script>
        function toggleAnswer(id) {
            var answer = document.getElementById(id);
            answer.classList.toggle('show');
        }

    document.addEventListener('DOMContentLoaded', function () {
        const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
        const cartNotification = document.getElementById('cart-notification');

        function updateCartNotification() {
            const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
            cartNotification.textContent = totalItems;
        }

        updateCartNotification(); // Ensure the function is called on each page load
    });

    </script>
</body>

</html>
