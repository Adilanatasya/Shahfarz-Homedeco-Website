<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user input from the form
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $phone = $_POST["phone"]; // New Field
    $address = $_POST["address"]; // New Field

    // Validate input (you should add more validation according to your requirements)

    // Example: Check if the username is not empty
    if (empty($username)) {
        die("Username is required");
    }

    // Example: Check if the email is valid
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format");
    }

    // Example: Check if the password is not empty
    if (empty($password)) {
        die("Password is required");
    }

    // Connect to the database
    $conn = mysqli_connect("localhost", "root", "", "project");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Example: Insert user data into the database (replace with your actual query)
    $query = "INSERT INTO users (username, email, password, phone, address) VALUES ('$username', '$email', '$password', '$phone', '$address')";

    if (mysqli_query($conn, $query)) {
        // Redirect with success parameter
        header("Location: signup.php?success=true");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    // Redirect to the signup page if the form is not submitted
    header("Location: signup.php");
    exit();
}
?>
