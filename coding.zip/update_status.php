<?php
// Include the database configuration file
include 'db_config.php';

// Check if it's a valid POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize the form data
    $orderId = intval($_POST["order_id"]);
    $status = $_POST["status"];

    // Prepare the SQL statement to update the status
    $sql = "UPDATE orderss SET status = ? WHERE order_id = ?";

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $status, $orderId);

    // Execute the prepared statement
    if ($stmt->execute()) {
        // Status updated successfully
        echo "Status updated successfully";
    } else {
        // Error updating status
        echo "Error updating status: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
} else {
    // Invalid request
    http_response_code(400); // Set HTTP response code to 400 Bad Request
    echo "Invalid request";
}

// Close the database connection
$conn->close();

// Redirect back to orderadmin.php after updating the status
header('Location: order_admin.php');
exit;
?>
