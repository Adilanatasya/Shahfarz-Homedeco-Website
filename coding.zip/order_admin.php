<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>SHAHFARZ HOMEDECO - Orders</title>
    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #fdf7f1;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
            align-items: center;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
           
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        .dropbtn {
            background-color: transparent;
            color: white;
            padding: 14px;
            font-size: 16px;
            border: none;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #8d7359;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown:hover .dropbtn {
            background-color: transparent;
        }

        /* Content Styles */
.content {
    flex: 1;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    padding: 20px;
}

.order {
    border: 1px solid #ddd;
    border-radius: 10px;
    padding: 20px;
    background-color: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: box-shadow 0.3s ease-in-out;
}

.order:hover {
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}

.order img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin-bottom: 15px;
}

.order-details {
    display: flex;
    flex-direction: column;
}

.order-details > * {
    margin-bottom: 10px;
}

.order-details > *:last-child {
    margin-bottom: 0;
}

.order-details button {
    padding: 10px 20px;
    background-color: #7d562d;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.order-details button:hover {
    background-color: #997a5a;
}

.product-list {
            margin-top: 10px;
            padding-left: 20px;
            list-style-type: decimal;
        }


        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
        }

        footer .left,
        footer .right {
            flex: 1;
            margin-bottom: 20px;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
            }

            .header-right {
                margin-top: 10px;
            }
        }
    </style>
</head>

<body>
    <div class="header">
        <a href="homepageadmin.php" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepageadmin.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompageadmin.php">Dining Room</a>
                    <a href="livingroompageadmin.php">Living Room</a>
                    <a href="bedroompageadmin.php">Bedroom</a>
                    <a href="entryroompageadmin.php">Entry Room</a>
                </div>
            </div>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="testimonialadmin.php">Testimonial</a>
            <a class="add-product" href="addproductform.php">
                <i class="fa fa-plus"></i>
            </a>
            <a class="order" href="order_admin.php">
    <i class="fa fa-shopping-cart"></i>
</a>
        </div>
    </div>

    <div class="content">
        <!-- Display orders -->


        <?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}




$sql = "SELECT orderss.*, users.username, users.address, users.phone, GROUP_CONCAT(cart.product_name SEPARATOR ', ') AS product_names 
        FROM orderss 
        INNER JOIN users ON orderss.user_id = users.id 
        INNER JOIN cart ON users.id = cart.user_id 
        GROUP BY orderss.order_id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        echo '<div class="order">';
        echo '<img src="' . $row["uploaded_receipt"] . '" alt="Receipt">';
        echo '<div class="order-details">';
        echo '<div class="order-info">';
        echo '<p><strong>Order ID:</strong> ' . $row["order_id"] . '</p>';
        echo '<p><strong>User ID:</strong> ' . $row["user_id"] . '</p>';
        echo '<p><strong>Order Date:</strong> ' . $row["order_date"] . '</p>';
        echo '<p><strong>Username:</strong> ' . $row["username"] . '</p>';
        echo '<p><strong>Address:</strong> ' . $row["address"] . '</p>';
        echo '<p><strong>Phone:</strong> ' . $row["phone"] . '</p>';
        echo '<p><strong>Status:</strong> ' . $row["status"] . '</p>';
        echo '</div>'; // Close order-info div

        // List of products with numbering
        $productList = explode(", ", $row["product_names"]);
        echo '<div class="product-list">';
        echo '<p><strong>Product List:</strong></p>';
        echo '<ul>';
        foreach ($productList as $key => $product) {
            echo '<li>' . $product . '</li>';
        }
        echo '</ul>';
        echo '</div>'; // Close product-list div

        echo '<div class="status-update">';
        echo '<form action="update_status.php" method="post">'; // Removed inline styles
        echo '<input type="hidden" name="order_id" value="' . $row["order_id"] . '">';

        // Add the label for "Status" just before the select element
        echo '<label for="status-' . $row["order_id"] . '">STATUS UPDATE:</label>';
        echo '<select name="status" id="status-' . $row["order_id"] . '">';
        echo '<option value="pending">Pending</option>';
        echo '<option value="on_its_way">On its way</option>';
        echo '<option value="delivered">Delivered</option>';
        echo '<option value="will_contact">Will contact</option>';
        echo '</select>';

        echo '<button type="submit">Update Status</button>';
        echo '</form>';
        echo '</div>'; // Close status-update div

        // Add the WhatsApp button here with dynamically retrieved phone number
        echo '<button onclick="window.location.href=\'https://api.whatsapp.com/send?phone=' . $row["phone"] . '\'">Contact via WhatsApp</button>';
        
        echo '</div>'; // Close order-details div
        echo '</div>'; // Close order div

    }
} else {
    echo "0 results";
}


$conn->close();
?>

</div>

<footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutusadmin.php">About</a>
            <a href="privacypolicyadmin.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faqadmin.php">FAQ</a>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="refundpolicyadmin.php">Refund Policy</a>
        </div>
    </footer>

    <script>
   function updateStatus(orderId) {
    // Retrieve the selected status value
    var status = document.getElementById("status-" + orderId).value;

    // Make a POST request to update the status
    fetch('update_status.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ order_id: orderId, status: status })
    })
    .then(response => response.text()) // Parse response as text
    .then(message => {
        console.log(message);
        // Check if status update was successful
        if (message.trim() === "Status updated successfully") { // Trim whitespace from message
            // Reload the page after successful status update
            location.reload();
        } else {
            // Handle errors here if needed
            console.error('Error:', message);
        }
    })
    .catch(error => console.error('Error:', error));
}



</script>





</body>
</html>
