<?php
// Include the database configuration file
include 'db_config.php';

// Check if it's a valid DELETE request and if the 'id' parameter is set
if ($_SERVER["REQUEST_METHOD"] == "DELETE" && isset($_GET['id'])) {
    // Sanitize the input to prevent SQL injection
    $productId = intval($_GET['id']);

    // Prepare the SQL statement to delete the product
    $sql = "DELETE FROM products WHERE id = ?";

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productId);

    // Execute the prepared statement
    if ($stmt->execute()) {
        // Product deleted successfully
        $response = ['success' => true, 'message' => 'Product deleted successfully'];
    } else {
        // Error deleting product
        $response = ['success' => false, 'message' => 'Error deleting product: ' . $stmt->error];
    }

    // Close the prepared statement
    $stmt->close();
} else {
    // Invalid request
    $response = ['error' => 'Invalid request'];
    http_response_code(400); // Set HTTP response code to 400 Bad Request
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn->close();
?>
