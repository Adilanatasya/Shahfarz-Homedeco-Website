<?php
session_start(); // Start the session

// Function to establish a PDO database connection
function db_connect() {
    $host = 'localhost'; // Change this to your database host
    $dbname = 'project'; // Change this to your database name
    $username = 'root'; // Change this to your database username
    $password = ''; // Change this to your database password

    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}

// Function to calculate total products in cart for the current user
function calculateTotalProductsInCart() {
    if(isset($_SESSION['user_id'])) {
        $userid = $_SESSION['user_id']; // Retrieve user ID from session

        $conn = db_connect(); // Connect to the database

        // Prepare SQL query
        $sql = "SELECT SUM(quantity) AS total_products FROM cart WHERE user_id = :userid";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':userid', $userid, PDO::PARAM_INT);

        // Execute statement
        $stmt->execute();

        // Fetch total products
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Close statement and database connection
        $stmt = null;
        $conn = null;

        return $result['total_products']; // Return total products
    } else {
        return 0; // If user ID is not set, return 0
    }
}

// Example usage:
$totalProducts = calculateTotalProductsInCart();

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Home - SHAHFARZ HOMEDECO</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background: #fdf7f1;
        }

        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

         img {
            vertical-align: middle;
        }

        .slideshow-container {
            max-width: 1000px;
            position: relative;
            margin: auto;
        }

        .prev, .next {
            cursor: pointer;
            position: absolute;
            top: 50%;
            width: auto;
            padding: 16px;
            margin-top: -22px;
            color: white;
            font-weight: bold;
            font-size: 18px;
            transition: 0.6s ease;
            border-radius: 0 3px 3px 0;
            user-select: none;
        }

        .next {
            right: 0;
            border-radius: 3px 0 0 3px;
        }

        .prev:hover, .next:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }

        .text {
            color: #f2f2f2;
            font-size: 15px;
            padding: 8px 12px;
            position: absolute;
            bottom: 8px;
            width: 100%;
            text-align: center;
        }

        .numbertext {
            color: #f2f2f2;
            font-size: 12px;
            padding: 8px 12px;
            position: absolute;
            top: 0;
        }

        .dot {
            cursor: pointer;
            height: 15px;
            width: 15px;
            margin: 0 2px;
            background-color: #bbb;
            border-radius: 50%;
            display: inline-block;
            transition: background-color 0.6s ease;
        }

        .active, .dot:hover {
            background-color: #717171;
        }

        .fade {
            animation-name: fade;
            animation-duration: 1.5s;
        }

        @keyframes fade {
            from {
                opacity: .4
            }

            to {
                opacity: 1
            }
        }

        @media only screen and (max-width: 300px) {
            .prev, .next,
            .text {
                font-size: 11px;
            }
        }
		
		div.gallery {
  border: 1px solid #ccc;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}

* {
  box-sizing: border-box;
}

.responsive {
        padding: 0 6px;
        float: left;
        width: 32%; /* Adjusted width to fit three images in a row with some spacing */
        margin: 6px 0;
    }

    @media only screen and (max-width: 700px) {
        .responsive {
            width: 49.99999%;
        }
    }

    @media only screen and (max-width: 500px) {
        .responsive {
            width: 100%;
        }
    }
		
		/* Add some spacing between the galleries */
        .responsive {
            padding: 10px;
        }

        /* Style the gallery images */
        .gallery img {
            width: 100%;
            height: auto;
            transition: transform 0.3s ease-in-out;
        }

        /* Add hover effects */
        .gallery:hover img {
            transform: scale(1.1);
        }
		.clearfix {
    padding: 20px;
    background-color: #f3ebda;
    text-align: center;
}

.clearfix p {
    margin: 0;
    font-size: 14px;
}
		
    .clearfix:after {
        content: "";
        display: table;
        clear: both;
    }
		
		 /* Zigzag Layout Styles */
        .container {
            padding: 2% 5%;
        }

        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        .column-66,
        .column-33 {
            float: left;
            width: 100%;
            box-sizing: border-box;
            padding: 20px;
        }

        .large-font {
            font-size: 48px;
        }

        .xlarge-font {
            font-size: 64px;
        }

        .button {
            border: none;
            color: white;
            padding: 14px 28px;
            font-size: 16px;
            cursor: pointer;
            background-color: #16537e;
        }

        img {
            display: block;
            max-width: 100%;
            height: auto;
            margin: 0 auto; /* Center align images */
        }

        @media screen and (min-width: 600px) {
            .column-66 {
                width: 66.66666%;
                float: left;
            }

            .column-33 {
                width: 33.33333%;
                float: left;
            }
        }

        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }
		
		.dropbtn {
  background-color: transparent;
  color: white;
  padding: 12px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #8d7359;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: transparent;}
		
    </style>
</head>

<body>
    <div class="header">
        <a href="homepage.php" class="logo">
    <img src="logoshahfarz.jpg" alt="Logo" style="max-width: 50px; max-height: 50px;">
    SHAHFARZ HOMEDECO
</a>

<div class="header-right">
            <a class="active" href="homepage.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompage.php">Dining Room</a>
                    <a href="livingroompage.php">Living Room</a>
                    <a href="bedroompage.php">Bedroom</a>
                    <a href="entryroompage.php">Entry Room</a>
                </div>
            </div>
    <a href="contactus.php">Contact Us</a>
    <a href="testimonial.php">Testimonial</a>
    <a class="cart" href="cart.php">
    <i class="fa fa-shopping-cart cart-icon"></i>
    <span id="cart-notification"><?php echo $totalProducts; ?></span>
</a>

    <a class="profile" href="profile.php">
        <i class="fa fa-user profile-icon"></i>
    </a>
</div>
    </div>
    <main>
		 <br>
        <div class="slideshow-container">
            <div class="mySlides fade">
                <img src="slide1.jpg" alt="slide1" style="width:100%">
            </div>

            <div class="mySlides fade">
                <img src="slide2.jpg" alt="slide2" style="width:100%">
            </div>

            <div class="mySlides fade">
                <img src="slide3.jpg" alt="slide3" style="width:100%">
            </div>

            <a class="prev" onclick="plusSlides(-1)">❮</a>
            <a class="next" onclick="plusSlides(1)">❯</a>

        </div>
        <br>

        <div style="text-align:center">
            <span class="dot" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <span class="dot" onclick="currentSlide(3)"></span>
        </div>

        <script>
            let slideIndex = 1;
            showSlides(slideIndex);

            function plusSlides(n) {
                showSlides(slideIndex += n);
            }

            function currentSlide(n) {
                showSlides(slideIndex = n);
            }

            function showSlides(n) {
                let i;
                let slides = document.getElementsByClassName("mySlides");
                let dots = document.getElementsByClassName("dot");
                if (n > slides.length) {
                    slideIndex = 1
                }
                if (n < 1) {
                    slideIndex = slides.length
                }
                for (i = 0; i < slides.length; i++) {
                    slides[i].style.display = "none";
                }
                for (i = 0; i < dots.length; i++) {
                    dots[i].className = dots[i].className.replace(" active", "");
                }
                slides[slideIndex - 1].style.display = "block";
                dots[slideIndex - 1].className += " active";
            }
        </script>
    </main>
	
    <!-- Living Room Section -->
    <div class="container" style="background-color:#f2e4d6">
        <div class="row">
            <div class="column-66">
              <p style="text-align: center; font-size: 24px;"><strong>Living Room</strong></p>
<p style="text-align: center; font-size: 24px;">&nbsp;</p>
<p style="text-align: center;">A living room is a room in a home used for socializing, entertaining, reading, watching TV, or playing games. It's often the first room that visitors see when entering the house.</p>
                <p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><a href="livingroompage.php" class="button">BUY NOW</a></p>
            </div>
            <div class="column-33">
                <img src="living.jpg" alt="Living Room">
            </div>
        </div>
    </div>

    <!-- Dining Room Section -->
    <div class="container" style="background-color:#faf0e7">
        <div class="row">
            <div class="column-33">
                <img src="kiki.jpg" alt="Dining Room" width="500" height="450">
            </div>
            <div class="column-66">
              <p style="text-align: center; font-size: 24px;"><strong>Dining Room</strong></p>
<p style="text-align: center; font-size: 24px;">&nbsp;</p>
<p style="text-align: center;">A dining room is a room where people eat meals. Dining rooms are usually located near the kitchen to make serving food easier.</p>
                <p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><a href="diningroompage.php" class="button" style="background-color:#16537e;">BUY NOW</a></p>
          </div>
        </div>
    </div>

    <!-- Entry Room Section -->
    <div class="container" style="background-color:#f2e4d6">
        <div class="row">
            <div class="column-66">
              <p style="text-align: center; font-size: 24px;"><strong>Entry Room</strong></p>
<p style="text-align: center; font-size: 24px;">&nbsp;</p>
<p style="text-align: center;">An entry way is a transitional space found in smaller homes, apartments, and homes with an open-floor plan.</p>
                <p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><a href="entryroompage.php" class="button">BUY NOW</a></p>
            </div>
            <div class="column-33">
                <img src="entry.jpg" alt="Entry Room" width="564" height="450">
            </div>
        </div>
    </div>

    <!-- Bedroom Section -->
    <div class="container" style="background-color:#faf0e7">
      <div class="row">
            <div class="column-33">
                <img src="bedroom.jpg" alt="Bedroom" width="564" height="376">
            </div>
            <div class="column-66">
              <p style="text-align: center; font-size: 24px;"><strong>Bedroom</strong></p>
<p style="text-align: center; font-size: 24px;">&nbsp;</p>
<p style="text-align: center;">A bedroom is a room in a home or apartment used for sleeping. It typically contains a bed, bedding, a window for egress, a door for privacy, and a minimum size requirement.</p>
                <p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><a href="bedroompage.php" class="button" style="background-color:#16537e;">BUY NOW</a></p>
        </div>
        </div>
    </div>

    <!-- Button for User Manual -->
<!-- Button for User Manual -->
<div class="container" style="background-color:#f2e4d6">
    <div class="row">
        <div class="column-100">
            <p style="text-align: center; font-size: 24px;"><strong>User Manual</strong></p>
            <p style="text-align: center;">Download the user manual for our products.</p>
            <br>
            <p style="text-align: center;"><a href="/project/USER%20MANUAL%20SHAHFARZ%20HOMEDECO%20WEBSITE.pdf" class="button" style="background-color:#16537e;">Download User Manual</a></p>
        </div>
    </div>
</div>

    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutus.php">About</a>
            <a href="privacypolicy.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faq.php">FAQ</a>
            <a href="contactus.php">Contact Us</a>
            <a href="refundpolicy.php">Refund Policy</a>
        </div>

    </footer>
    
</body>

</html>