<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>About Us - Shahfarz Homedeco</title>
    <style>
        /* Extracted Header Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background: #fdf7f1;
        }

        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        img {
            vertical-align: middle;
        }

        /* Extracted Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            text-align: left;
            padding: 10px; /* Adjusted to match the padding of the header */
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }

        .about-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            padding: 20px;
            justify-content: center;
            align-items: center;
        }

        .about-content img {
            max-width: 100%;
            height: auto;
            display: block;
            margin: 0 auto; /* Added to center the image horizontally */
        }

        .about-text {
            text-align: justify;
        }

        html {
            box-sizing: border-box;
        }

        *,
        *:before,
        *:after {
            box-sizing: inherit;
        }

         .column {
            float: left;
            width: 33.3%;
            margin-bottom: 16px;
            padding: 0 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
        } align-items: center;
        }

        @media screen and (max-width: 650px) {
            .column {
                width: 100%;
                display: block;
            }
        }

        .column .card {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .container {
            padding: 0 16px;
        }

        .container::after,
        .row::after {
            content: "";
            clear: both;
            display: table;
        }

        .title {
            color: grey;
        }

        .button {
            border: none;
            outline: 0;
            display: inline-block;
            padding: 8px;
            color: white;
            background-color: #d8a95e;
            text-align: center;
            cursor: pointer;
            width: 100%;
        }

        .button:hover {
            background-color: #e7c38c;
        }

        .column img {
            width: 100%;
            height: auto;
            border-radius: 50%;
            max-width: 150px; /* Adjust the size as needed */
        }
		
		.column img {
            width: 100%;
            height: 150px; /* Adjust the height as needed for uniformity */
            object-fit: cover;
            border-radius: 50%;
        }
		
		h2 {
    text-align: center;
    margin-top: 20px; /* Adjust the margin as needed */
	color: #593806;
}
		
		.row {
    background-color: #ede1d4; /* Add your desired background color here */
    padding: 20px; /* Adjust the padding as needed */
}
		
		a {
    color: black;
    text-decoration: none; /* Optional: Removes underline */
}
		
		.dropbtn {
  background-color: transparent;
  color: white;
  padding: 11px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #8d7359;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: transparent;}
		
    </style>
</head>

<body>
    <!-- Header Section -->
    <div class="header">
        <a href="homepageadmin.php" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepageadmin.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompageadmin.php">Dining Room</a>
                    <a href="livingroompageadmin.php">Living Room</a>
                    <a href="bedroompageadmin.php">Bedroom</a>
                    <a href="entryroompageadmin.php">Entry Room</a>
                </div>
            </div>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="testimonialadmin.php">Testimonial</a>
            <a class="add-product" href="addproductform.php">
                <i class="fa fa-plus"></i>
            </a>
            
            <a class="order" href="order_admin.php">
    <i class="fa fa-shopping-cart"></i>
</a>
        </div>
    </div>


    <!-- Main Content Section -->
    <main class="about-content">
        <img src="aboutlogo.jpg" alt="About Us Image">
        <div class="about-text">
            <h1>About Us</h1>
            <p>Shahfarz Homedeco originated during the Malaysia Movement Control Order, founded by a primary school teacher and a full-time lorry driver in response to the challenges of that time. Operating entirely from home, the business curates furniture materials designed to seamlessly integrate with daily living environments.</p>
            <p>With a vision to expand, Shahfarz Homedeco plans to develop a dedicated website, serving as an interactive display for carefully selected furniture items. The objective is to establish Shahfarz Homedeco as a recognizable brand, with a user-friendly layout facilitating easy exploration of product selections.</p>
            <p>Recognizing the importance of personalized interactions in the furniture industry, Shahfarz Homedeco commits to direct communication via WhatsApp, bridging the gap between online browsing and individual discussions for a tailored and appreciated customer experience. In summary, Shahfarz Homedeco's journey is rooted in adaptive responses to challenges, evolving into a home-based business redefining the connection between homes and business activities through curated furniture offerings and personalized service.</p>
        </div>
    </main>

    <br>

    <h2>MEET THE TEAM</h2>
    <br>

    <div class="row">
       <div class="column">
    <div class="card">
        <img src="abah.jpeg" alt="Jane">
        <div class="container">
            <h2>Shahabdeen</h2>
            <p class="title">FOUNDER</p>
            <p>wbudeen@gmail.com</p>
            <p>
                <a href="mailto:wbudeen@gmail.com" class="button">Contact</a>
            </p>
        </div>
    </div>
</div>

<div class="column">
    <div class="card">
        <img src="ibu.jpeg" alt="Mike">
        <div class="container">
            <h2>Farzlinda</h2>
            <p class="title">FOUNDER&nbsp;</p>
            <p>farzlinda@gmail.com</p>
            <p>
                <a href="mailto:farzlinda@gmail.com" class="button">Contact</a>
            </p>
        </div>
    </div>
</div>

<div class="column">
    <div class="card">
        <img src="nyanya.jpeg" alt="Jane">
        <div class="container">
            <h2>Dania</h2>
            <p class="title">MANAGER</p>
            <p>dnjazlina@gmail.com</p>
            <p>
                <a href="mailto:dnjazlina@gmail.com" class="button">Contact</a>
            </p>
        </div>
    </div>
</div>




        <div class="column">
    <div class="card">
        <img src="tah.jpeg" alt="John">
        <div class="container">
            <h2>Syafiqah</h2>
            <p class="title">FURNITURE INSTALLER</p>
            <p>syfq4hh@gmail.com</p>
            <p>
                <a href="mailto:syfq4hh@gmail.com" class="button">Contact</a>
            </p>
        </div>
    </div>
</div>
    </div>

    <!-- Footer Section -->
    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutusadmin.php">About</a>
            <a href="privacypolicyadmin.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faqadmin.php">FAQ</a>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="refundpolicyadmin.php">Refund Policy</a>
        </div>
    </footer>
    

</body>

</html>
