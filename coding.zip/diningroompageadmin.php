<?php include 'db_config.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>DINING ROOM</title>
    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #fdf7f1;
            line-height: 1.6;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        /* Dropdown Styles */
        .dropbtn {
            background-color: transparent;
            color: white;
            padding: 13px;
            font-size: 16px;
            border: none;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {background-color: #8d7359;}

        .dropdown:hover .dropdown-content {display: block;}

        .dropdown:hover .dropbtn {background-color: transparent;}

        /* Product Section */
        .product-section {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 20px;
        }

        .product {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .product-item {
            flex-basis: calc(33.33% - 20px);
            margin-bottom: 20px;
            box-sizing: border-box;
        }

        .product-image {
            position: relative;
            overflow: hidden;
            margin-bottom: 10px;
        }

        .product-image img {
            width: 100%;
            transition: transform 0.3s ease;
        }

        .product-image:hover img {
            transform: scale(1.1);
        }

        .product-details {
            margin-bottom: 10px;
        }

        .product-name {
            font-size: 18px;
            margin-bottom: 5px;
        }

        .product-price {
            font-size: 16px;
            color: #888;
            margin-bottom: 10px;
        }

        .edit-delete-buttons {
            display: flex;
            justify-content: space-between;
        }

        .edit-delete-buttons button {
            padding: 8px;
            width: 48%;
            background-color: #000;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .edit-delete-buttons button:hover {
            background-color: #333;
        }

        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }
    </style>
</head>

<body>
    <div class="header">
        <a href="homepageadmin.php" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepageadmin.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompageadmin.php">Dining Room</a>
                    <a href="livingroompageadmin.php">Living Room</a>
                    <a href="bedroompageadmin.php">Bedroom</a>
                    <a href="entryroompageadmin.php">Entry Room</a>
                </div>
            </div>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="testimonialadmin.php">Testimonial</a>
            <a class="add-product" href="addproductform.php">
                <i class="fa fa-plus"></i>
            </a>
            <a class="order" href="order_admin.php">
    <i class="fa fa-shopping-cart"></i>
</a>
        </div>
    </div>

    <div class="product-section">
        <div class="product">
            <?php
            $category = "Dining room";
            $sql = "SELECT * FROM products WHERE category = '$category'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="product-item">';
                    echo '<div class="product-image">';
                    echo '<img src="' . $row['product_image_path'] . '" alt="Product Image">';
                    echo '</div>';
                    echo '<div class="product-details">';
                    echo '<h2 class="product-name">' . $row['product_name'] . '</h2>';
                    echo '<p class="product-price">RM' . $row['product_price'] . '</p>';
                    echo '<div class="edit-delete-buttons">';
                    echo '<button onclick="editProduct(' . $row['id'] . ', \'' . $row['product_name'] . '\', \'' . $row['product_price'] . '\', \'' . $row['product_image_path'] . '\', \'' . $category . '\')">Edit</button>';
                    echo '<button onclick="deleteProduct(' . $row['id'] . ')">Delete</button>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo 'No products found.';
            }
            ?>
        </div>
    </div>

    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutusadmin.php">About</a>
            <a href="privacypolicyadmin.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faqadmin.php">FAQ</a>
            <a href="contactusadmin.php">Contact Us</a>
            <a href="refundpolicyadmin.php">Refund Policy</a>
        </div>
    </footer>
</body>

<!-- Inside the <script> tag in the head of your HTML file -->
<script>
    function editProduct(id, productName, productPrice, productImagePath, productCategory) {
        // Prompt user for new values
        var newProductName = prompt("Enter new product name:", productName);
        var newProductPrice = prompt("Enter new product price:", productPrice);
        var newProductImagePath = prompt("Enter new product image path:", productImagePath);

        // Make sure user entered values and is not null
        if (newProductName !== null && newProductPrice !== null && newProductImagePath !== null) {
            // Create a FormData object to send data in the request body
            var formData = new FormData();
            formData.append('id', id);
            formData.append('product_name', newProductName);
            formData.append('product_price', newProductPrice);
            formData.append('product_image_path', newProductImagePath);
            formData.append('category', productCategory); // Pass the existing category value

            // Use fetch API to send a POST request with data in the request body
            fetch('process_update_product.php', {
                method: 'POST',
                body: formData
            })
           
            .then(response => response.json())
            .then(data => {
                console.log(data);
                // Handle the response from the PHP script here
                if (data.success) {
                    // Optionally, display a success message to the user
                    alert("Product updated successfully");
                    // Reload the page to reflect the changes
                    window.location.reload();
                } else {
                    // Handle the case where the update operation failed
                    alert("Error: " + data.message);
                }
            })
            .catch(error => console.error('Error:', error));
        }
    }


    function deleteProduct(id) {
        if (confirm("Are you sure you want to delete this product?")) {
            console.log("Deleting product with ID: " + id);

            // Using fetch API for simplicity
            fetch('delete_product.php?id=' + id, { method: 'DELETE' })
              
            
            .then(response => response.json())
                .then(data => {
                    console.log(data);
                    // Handle the response from the PHP script here
                    if (data.success) {
                        // Optionally, display a success message to the user
                        alert("Product deleted successfully");
                        // Reload the page to reflect the changes
                        window.location.reload();
                    } else {
                        // Handle the case where the deletion operation failed
                        alert("Error: " + data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
        }
    }
</script>


</html>
