<?php
// Include the database configuration file
include 'db_config.php';

// Check if it's a valid POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize the form data
    $productId = intval($_POST["id"]);
    $productName = $_POST["product_name"];
    $productPrice = floatval($_POST["product_price"]);
    $productImagePath = $_POST["product_image_path"];

    // Prepare the SQL statement to update the product
    $sql = "UPDATE products SET 
            product_name = ?, 
            product_price = ?, 
            product_image_path = ?
            WHERE id = ?";

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdsi", $productName, $productPrice, $productImagePath, $productId);

    // Execute the prepared statement
    if ($stmt->execute()) {
        // Product updated successfully
        $response = ['success' => true, 'message' => 'Product updated successfully'];
    } else {
        // Error updating product
        $response = ['success' => false, 'message' => 'Error updating product: ' . $stmt->error];
    }

    // Close the prepared statement
    $stmt->close();
} else {
    // Invalid request
    $response = ['error' => 'Invalid request'];
    http_response_code(400); // Set HTTP response code to 400 Bad Request
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn->close();
?>
