<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user data from the database
$userID = $_SESSION['user_id'];
$query = "SELECT username, email, phone, address FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $userID);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) > 0) {
    $userData = mysqli_fetch_assoc($result);
} else {
    // Handle the case where user data is not found
    $userData = array('username' => '', 'email' => '', 'phone' => '', 'address' => '');
}


// Retrieve cart items for the logged-in user from the database
$userId = $_SESSION['user_id'];
$sqlCartItems = "SELECT * FROM cart WHERE user_id = '$userId'";
$resultCartItems = $conn->query($sqlCartItems);

// Store cart items in an array
$cartItems = [];
if ($resultCartItems->num_rows > 0) {
    while ($row = $resultCartItems->fetch_assoc()) {
        $cartItems[] = array(
            'id' => $row['id'],
            'name' => $row['product_name'],
            'price' => $row['product_price'],
            'quantity' => $row['quantity']
            // Add other properties if needed
        );
    }
}

// Calculate total amount based on cart items
$totalAmount = 0;
foreach ($cartItems as $item) {
    $totalAmount += $item['price'] * $item['quantity'];
}



// Handle the form submission for updating profile information
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Extract the form data
    $name = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);

    // Update user information in the 'users' table
    $updateQuery = "UPDATE users SET username = ?, email = ?, phone = ?, address = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, "ssssi", $name, $email, $phone, $address, $userID);
    $updateResult = mysqli_stmt_execute($stmt);

    // Check for errors
    if (!$updateResult) {
        die("Error updating record: " . mysqli_error($conn));
    }

    // Redirect to a success page after successful update
    header("Location: success.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Shahfarz HomeDeco</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #fdf7f1;
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        .dropbtn {
            background-color: transparent;
            color: white;
            padding: 14px;
            font-size: 16px;
            border: none;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #8d7359;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown:hover .dropbtn {
            background-color: transparent;
        }

        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #efe1d3;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }

        label {
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s;
            box-sizing: border-box;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="tel"]:focus,
        textarea:focus {
            outline: none;
            border-color: #957b61;
        }

        .submit-btn {
            background-color: #957b61;
            color: #fff;
            border: none;
            padding: 15px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            display: block;
            width: 93%;
            margin-top: 20px;
            text-align: center;
            text-decoration: none;
        }

        .submit-btn:hover {
            background-color: #7c6957;
        }

        .image-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .image-container img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .error-message {
            color: #ff0000;
            font-size: 14px;
            margin-top: -10px;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

<div class="header">
    <a href="homepage.php" class="logo">
        <img src="logoshahfarz.jpg" alt="Logo">
        SHAHFARZ HOMEDECO
    </a>

    <div class="header-right">
        <a class="active" href="homepage.php">Home</a>
        <div class="dropdown">
            <button class="dropbtn">Products</button>
            <div class="dropdown-content">
                <a href="diningroompage.php">Dining Room</a>
                <a href="livingroompage.php">Living Room</a>
                <a href="bedroompage.php">Bedroom</a>
                <a href="entryroompage.php">Entry Room</a>
            </div>
        </div>
        <a href="contactus.php">Contact Us</a>
        <a href="testimonial.php">Testimonial</a>
        <a class="cart" href="cart.php">
            <i class="fa fa-shopping-cart cart-icon"></i>
        </a>
        <a class="profile" href="profile.php">
            <i class="fa fa-user profile-icon"></i>
        </a>
    </div>
</div>

<div class="container">
    <h2>Checkout</h2>
    <form action="placeorder.php" method="POST" id="checkout-form" onsubmit="return validateForm()">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="username" value="<?php echo $userData['username']; ?>" required>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $userData['email']; ?>" required>
        </div>

        <div class="form-group">
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" value="<?php echo isset($userData['address']) ? $userData['address'] : ''; ?>">
        </div>

        <div class="form-group">
            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" value="<?php echo isset($userData['phone']) ? $userData['phone'] : ''; ?>">
        </div>

        <div class="form-group">
            <label for="total">Total Amount</label>
            <!-- Assuming $totalAmount is defined elsewhere in your code -->
            <input type="text" id="total" name="total_amount" value="<?php echo 'RM' . number_format($totalAmount, 2); ?>" readonly>
        </div>

        <!-- Example: Add hidden input fields to pass data to placeorder.php -->
        <input type="hidden" name="total" value="<?php echo $totalAmount; ?>">
        <input type="hidden" name="user_id" value="<?php echo $userID; ?>">

        <button type="submit" class="submit-btn">PLACE ORDER</button>
    </form>
</div>

<footer>
    <div class="left">
        <strong>GET IN TOUCH</strong>
        <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
    </div>

    <div class="left">
        <strong>FOLLOW US</strong>
        <p>
            <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
        </p>
    </div>

    <div class="right">
        <strong>SHAHFARZ HOMEDECO</strong>
        <a href="aboutus.php">About</a>
        <a href="privacypolicy.php">Privacy Policy</a>
    </div>

    <div class="right">
        <strong>CUSTOMER SUPPORT</strong>
        <a href="faq.php">FAQ</a>
        <a href="contactus.php">Contact Us</a>
        <a href="refundpolicy.php">Refund Policy</a>
    </div>
</footer>

<script>
    function validateForm() {
        var fullname = document.getElementById('name').value;
        var email = document.getElementById('email').value;
        var phone = document.getElementById('phone').value;
        var address = document.getElementById('address').value;

        var errorMessage = "";

        if (fullname.trim() == "") {
            errorMessage += "Please enter your full name.\n";
        }

        if (email.trim() == "") {
            errorMessage += "Please enter your email.\n";
        } else if (!validateEmail(email)) {
            errorMessage += "Please enter a valid email address.\n";
        }

        if (phone.trim() == "") {
            errorMessage += "Please enter your phone number.\n";
        } else if (!validatePhone(phone)) {
            errorMessage += "Please enter a valid phone number.\n";
        }

        if (address.trim() == "") {
            errorMessage += "Please enter your address.\n";
        }

        if (errorMessage != "") {
            alert(errorMessage);
            return false;
        }

        return true;
    }

    function validateEmail(email) {
        var re = /\S+@\S+\.\S+/;
        return re.test(email);
    }

    function validatePhone(phone) {
        var re = /^\d{10}$/;
        return re.test(phone);
    }

</script>

</body>

</html>
