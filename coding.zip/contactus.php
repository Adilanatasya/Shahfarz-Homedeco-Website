<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

// Check if the user is authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user data from the database
$userID = $_SESSION['user_id'];
$query = "SELECT username, email, phone FROM users WHERE id = $userID";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $userData = mysqli_fetch_assoc($result);
} else {
    // Handle the case where user data is not found
    $userData = array('username' => '', 'email' => '', 'phone' => '');
}

// Handle the form submission for updating profile information
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Extract the form data
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Insert the form data into the 'contact' table
    $insertQuery = "INSERT INTO contact (custID, name, email, phonenumber, messages) 
                    VALUES ('$userID', '$name', '$email', '$phone', '$message')";
    $insertResult = mysqli_query($conn, $insertQuery);

    // Check for errors
    if (!$insertResult) {
        die("Error inserting record: " . mysqli_error($conn));
    }

    // Check if the insertion was successful
    if ($insertResult) {
        // Redirect or perform other actions after successful insertion
        header("Location: contactus.php"); // Redirect to a success page
        exit();
    } else {
        // Handle the case where the insertion fails
        $errorMessage = "Failed to submit the form. Please try again.";
    }
}


// Retrieve cart items for the logged-in user from the database
$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM cart WHERE user_id = '$userId'";
$result = $conn->query($sql);

// Function to calculate total products in cart for the current user
function calculateTotalProductsInCart($conn) {
    if(isset($_SESSION['user_id'])) {
        $userid = $_SESSION['user_id']; // Retrieve user ID from session

        // Prepare SQL query
        $sql = "SELECT SUM(quantity) AS total_products FROM cart WHERE user_id = '$userid'";

        // Execute SQL query
        $result = $conn->query($sql);

        // Check if query was successful
        if ($result) {
            // Fetch total products
            $row = $result->fetch_assoc();
            $totalProducts = $row['total_products'];

            return $totalProducts; // Return total products
        } else {
            // Query failed
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        return 0; // If user ID is not set, return 0
    }
}

// Example usage:
$totalProducts = calculateTotalProductsInCart($conn);



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Contact Us - SHAHFARZ HOMEDECO</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background: #fdf7f1;
        }

        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        .contact-section {
            text-align: center;
            padding: 50px;
        }

        .contact-grid {
            display: flex;
            align-items: center;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .icon-container .whatsapp-icon,
        .icon-container .phone-icon {
            font-size: 100px;
            margin-bottom: 10px;
            color: #25D366; /* Set the color you prefer for the icons */
        }

        .contact-details a {
            color: #000; /* Set the color for the links */
            text-decoration: none;
        }

        .contact-details a:hover {
            text-decoration: underline; /* Add underline on hover if you like */
        }

        .contact-details {
            font-size: 18px;
        }
footer {
    background-color: #564c41;
    color: #fff;
    text-align: left;
    padding: 20px 10px;    
    display: flex;
    justify-content: space-between;
    align-items: center;
	overflow-x: hidden;
    width: 98%;

}

footer .left,
footer .right {
    flex: 1;
}

footer .right {
    text-align: right;
}

footer a {
    color: #fff;
    text-decoration: none;
    display: block;
    margin-bottom: 5px;
}

.fa-facebook-bg {
    background: #3B5998;
    padding: 10px;
    border-radius: 50%;
}

		
		 /* Style for the form container */
        .contact-form-container {
            max-width: 600px; /* Adjust as needed */
            margin: 0 auto;
            padding: 20px;
            background-color: #e5d8c9;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .contact-form {
            text-align: left;
        }

        .contact-form label {
            display: block;
            margin-bottom: 10px;
        }

        .contact-form input[type="text"],
        .contact-form input[type="email"],
        .contact-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .contact-form textarea {
            height: 150px;
        }

        .contact-form button {
            background-color: #000;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .contact-form button:hover {
            background-color: #333;
        } 
	
	.dropbtn {
  background-color: transparent;
  color: white;
  padding: 11px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #8d7359;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: transparent;}
		
	</style>

</head>

<body>
    <div class="header">
        <a href="homepage.php" class="logo">
    <img src="logoshahfarz.jpg" alt="Logo" style="max-width: 50px; max-height: 50px;">
    SHAHFARZ HOMEDECO
</a>
<div class="header-right">
            <a class="active" href="homepage.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompage.php">Dining Room</a>
                    <a href="livingroompage.php">Living Room</a>
                    <a href="bedroompage.php">Bedroom</a>
                    <a href="entryroompage.php">Entry Room</a>
                </div>
            </div>
    <a href="contactus.php">Contact Us</a>
    <a href="testimonial.php">Testimonial</a>
    <a class="cart" href="cart.php">
    <i class="fa fa-shopping-cart cart-icon"></i>
    <span id="cart-notification"><?php echo $totalProducts; ?></span>
</a>

    <a class="profile" href="profile.php">
        <i class="fa fa-user profile-icon"></i>
    </a>
</div>
    </div>

    <br>
    <br>

 <!-- Display container status -->
 <?php if (isset($containerStatus)): ?>
        <p>Container Status: <?php echo $containerStatus; ?></p>
        <?php endif; ?>
    </div>

	<!-- Contact Form Container -->
<div class="contact-form-container">
    <div class="contact-form">
        <h2>WE ARE HAPPY TO HEAR FROM YOU</h2>
        <form action="#" method="post">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $userData['username']; ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $userData['email']; ?>" required>

            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" value="<?php echo $userData['phone']; ?>">

            <label for="message">Message:</label>
            <textarea id="message" name="message" required></textarea>

            <button type="submit">Submit</button>
        </form>
    </div>
</div>
<br>

<div class="contact-section">
        <div class="contact-grid">
            <div class="icon-container">
                <div class="whatsapp-icon">
                    <i class="fa fa-whatsapp"></i>
                </div>
                <div class="contact-details">
					<p>Live Chat</p>
					<p><a href="https://api.whatsapp.com/send?phone=0136553197" target="_blank">+60136553197</a></p>
					<p>Monday - Saturday</p>
					<p>9:00am - 6:00pm</p>
                </div>
            </div>

            <div class="icon-container">
                <div class="phone-icon">
                    <i class="fa fa-phone"></i>
                </div>
                <div class="contact-details">
                    <p>Phone Calls</p>
                    <p><a href="tel:+60136773405">+60136773405</a></p>
					<p>Monday - Saturday</p>
					<p>9:00am - 6:00pm</p>
                </div>
            </div>
        </div>

        <div class="additional-details">
            <p>Feel free to reach out to us via WhatsApp or give us a call for any inquiries or assistance.</p>
            <p>Our customer support team is available to help you.</p>
        </div>
    </div>

	    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p style="line-height: 18px;"><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutus.php">About</a>
            <a href="privacypolicy.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faq.php">FAQ</a>
            <a href="contactus.php">Contact Us</a>
            <a href="refundpolicy.php">Refund Policy</a>
        </div>
    </footer>

   

</body>

</html>
