<?php
session_start();

// Database connection details
$hostname = "localhost";
$username = "root";
$password = "";
$database = "project";

// Create a connection to the database
$conn = new mysqli($hostname, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in (assuming you have a user authentication system)
if (!isset($_SESSION['user_id'])) {
    // Redirect the user to the login page or display a message
    header("Location: login.php");
    exit();
}

// Function to remove item from cart
function removeFromCart($conn, $userId, $productId) {
    $sql = "DELETE FROM cart WHERE user_id = '$userId' AND product_id = '$productId'";
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Handle remove item request
if (isset($_POST['remove_item'])) {
    $userId = $_SESSION['user_id'];
    $productId = $_POST['product_id'];
    if (removeFromCart($conn, $userId, $productId)) {
        echo json_encode(array("success" => true));
    } else {
        echo json_encode(array("success" => false));
    }
    exit();
}

// Retrieve cart items for the logged-in user from the database
$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM cart WHERE user_id = '$userId'";
$result = $conn->query($sql);

// Store cart items in an array
$cartItems = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cartItems[] = array(
            'id' => $row['id'],
            'name' => $row['product_name'],
            'price' => $row['product_price'],
            'quantity' => $row['quantity']
            // Add other properties if needed
        );
    }
}

// Function to calculate total products in cart for the current user
function calculateTotalProductsInCart() {
    if(isset($_SESSION['user_id'])) {
        $userid = $_SESSION['user_id']; // Retrieve user ID from session

        // Establish database connection
        $conn = new mysqli($GLOBALS['hostname'], $GLOBALS['username'], $GLOBALS['password'], $GLOBALS['database']);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare SQL query
        $sql = "SELECT SUM(quantity) AS total_products FROM cart WHERE user_id = '$userid'";

        // Execute SQL query
        $result = $conn->query($sql);

        // Check if query was successful
        if ($result) {
            // Fetch total products
            $row = $result->fetch_assoc();
            $totalProducts = $row['total_products'];

            // Close database connection
            $conn->close();

            return $totalProducts; // Return total products
        } else {
            // Query failed
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        return 0; // If user ID is not set, return 0
    }
}

        
        // Example usage:
        $totalProducts = calculateTotalProductsInCart();
        


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Cart - Shahfarz HomeDeco</title>

    <style>
        /* Reset CSS */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #fdf7f1;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Header Styles */
        .header {
            background-color: #000000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }

        .logo img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .header a {
            text-decoration: none;
            color: white;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right {
            display: flex;
        }

        .header-right a {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .header-right a:hover {
            background-color: transparent;
            color: white;
        }

        .header-right .cart-icon,
        .header-right .profile-icon {
            font-size: 20px;
            margin-right: 8px;
        }

        .dropbtn {
            background-color: transparent;
            color: white;
            padding: 14px;
            font-size: 16px;
            border: none;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #8d7359;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown:hover .dropbtn {
            background-color: transparent;
        }

        /* Footer Styles */
        footer {
            background-color: #564c41;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-top: auto;
        }

        footer .left,
        footer .right {
            flex: 1;
        }

        footer .right {
            text-align: right;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .fa-facebook-bg {
            background: #3B5998;
            padding: 10px;
            border-radius: 50%;
        }

        /* Cart Page Styles */
        .cart-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .cart-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.cart-table th,
.cart-table td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: left;
}

.cart-table th {
    background-color: #c0b799;
    color: #fff;
}

.cart-table tr:nth-child(even) {
    background-color: #ece3e3;
}

.cart-table tr:hover {
    background-color: #ebe1e1;
}

.quantity-btns {
    display: flex;
    align-items: center;
}

.quantity-btns button {
    padding: 5px 10px;
    margin: 0 5px;
    border: none;
    background-color: #ccc;
    cursor: pointer;
    border-radius: 3px;
}

.remove-item-btn {
    padding: 5px 10px;
    border: none;
    background-color: #cc0000;
    color: #fff;
    cursor: pointer;
    border-radius: 3px;
}

.total-row {
    background-color: #f0f0f0;
    font-weight: bold;
}


        .remove-item-btn:hover {
            background-color: #990000;
        }

        /* Your CSS styles */
        .checkout-button {
            background-color: #957b61;
            border: none;
            color: white;
            padding: 15px 30px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 10px;
            transition: background-color 0.3s;
        }

        .checkout-button:hover {
            background-color: #7c6957;
        }

        .total-row {
            background-color: #fdf7f1;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="header">
        <a href="homepage.php" class="logo">
            <img src="logoshahfarz.jpg" alt="Logo">
            SHAHFARZ HOMEDECO
        </a>

        <div class="header-right">
            <a class="active" href="homepage.php">Home</a>
            <div class="dropdown">
                <button class="dropbtn">Products</button>
                <div class="dropdown-content">
                    <a href="diningroompage.php">Dining Room</a>
                    <a href="livingroompage.php">Living Room</a>
                    <a href="bedroompage.php">Bedroom</a>
                    <a href="entryroompage.php">Entry Room</a>
                </div>
            </div>
            <a href="contactus.php">Contact Us</a>
            <a href="testimonial.php">Testimonial</a>
            <a class="cart" href="cart.php">
    <i class="fa fa-shopping-cart cart-icon"></i>
    <span id="cart-notification"><?php echo $totalProducts; ?></span>
</a>

            <a class="profile" href="profile.php">
                <i class="fa fa-user profile-icon"></i>
            </a>
        </div>
    </div>


    <div class="cart-container">
    <table class="cart-table">
    <thead>
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody id="cart-items">
        <?php
        if (!empty($cartItems)) {
            foreach ($cartItems as $item) {
                echo "<tr>";
                echo "<td>" . $item['name'] . "</td>";
                echo "<td>RM" . $item['price'] . "</td>";
                echo "<td class='quantity'>";
                echo "<div class='quantity-btns'>";
                echo "<button class='decrease-btn'>-</button>";
                echo "<span>" . $item['quantity'] . "</span>";
                echo "<button class='increase-btn'>+</button>";
                echo "</div>";
                echo "</td>";
                echo "<td>RM" . ($item['price'] * $item['quantity']) . "</td>";
                echo "<td><button class='remove-item-btn' data-product-id='" . $item['id'] . "'>Remove</button></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Cart is empty</td></tr>";
        }
        ?>
    </tbody>
    <tfoot>
        <tr class="total-row">
            <td colspan="3"></td>
            <td>Total:</td>
            <td id="total-price">RM 0.00</td>
        </tr>
    </tfoot>
</table>

    </div>

    <!-- Add Checkout button in the middle of the page -->
    <div style="text-align: center; margin-top: 20px;">
        <p><a href="checkoutpage.php" class="checkout-button">Checkout</a></p>
        <p>&nbsp;</p>
    </div>

    <footer>
        <div class="left">
            <strong>GET IN TOUCH</strong>
            <p><i class="fa fa-phone" style="font-size: 18px; margin-right: 5px; vertical-align: middle;"></i> <a href="tel:+60136553197" style="vertical-align: middle;">+60 13 655 3197</a></p>
        </div>

        <div class="left">
            <strong>FOLLOW US</strong>
            <p>
                <a href="https://www.facebook.com/shahfarzhomedeco" target="_blank" class="fa fa-facebook fa-facebook-bg"></a>
            </p>
        </div>

        <div class="right">
            <strong>SHAHFARZ HOMEDECO</strong>
            <a href="aboutus.php">About</a>
            <a href="privacypolicy.php">Privacy Policy</a>
        </div>

        <div class="right">
            <strong>CUSTOMER SUPPORT</strong>
            <a href="faq.php">FAQ</a>
            <a href="contactus.php">Contact Us</a>
            <a href="refundpolicy.php">Refund Policy</a>
        </div>
    </footer>

    <script>
        // JavaScript code for handling cart functionality
document.addEventListener('DOMContentLoaded', function () {
    const cartItems = <?php echo json_encode($cartItems); ?>; // PHP array to JavaScript array

    const cartTableBody = document.getElementById('cart-items');
    const totalPriceElement = document.getElementById('total-price');

    // Function to render cart items
    function renderCartItems() {
        cartTableBody.innerHTML = '';
        let totalPrice = 0;

        cartItems.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.name}</td>
                <td>RM ${item.price}</td>
                <td class="quantity">
                    <button class="decrease-btn">-</button>
                    <span>${item.quantity}</span>
                    <button class="increase-btn">+</button>
                </td>
                <td>RM ${(item.price * item.quantity).toFixed(2)}</td>
                <td>
                    <button class="remove-item-btn" data-product-id="${item.id}">Remove</button>
                </td>
            `;
            cartTableBody.appendChild(row);

            totalPrice += item.price * item.quantity;
        });

        totalPriceElement.textContent = totalPrice.toFixed(2);
    }

    // Function to update cart in localStorage
    function updateCart() {
        localStorage.setItem('cart', JSON.stringify(cartItems));
        renderCartItems();
    }

    // Event listener for handling increase, decrease, and remove item actions
    cartTableBody.addEventListener('click', function (event) {
        const target = event.target;
        const index = Array.from(target.closest('tr').parentElement.children).indexOf(target.closest('tr'));
        const item = cartItems[index];

        if (target.classList.contains('decrease-btn')) {
            if (item.quantity > 1) {
                item.quantity--;
                updateCart();
            }
        } else if (target.classList.contains('increase-btn')) {
            item.quantity++;
            updateCart();
        } else if (target.classList.contains('remove-item-btn')) {
            const productId = target.getAttribute('data-product-id');
            removeFromCart(productId, index);
        }
    });

    // Function to handle removing an item from the cart
    function removeFromCart(productId, index) {
        // Send AJAX request to remove item from cart
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'cart.php');
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function () {
            if (xhr.status === 200) {
                // Item removed successfully
                cartItems.splice(index, 1);
                updateCart();
            } else {
                // Error occurred
                console.error('Error removing item:', xhr.responseText);
            }
        };
        xhr.send('remove_item=' + productId);
    }
});

    </script>
</body>

</html>
